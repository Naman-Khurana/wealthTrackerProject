package com.springbootproject.wealthtracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WealthtrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
