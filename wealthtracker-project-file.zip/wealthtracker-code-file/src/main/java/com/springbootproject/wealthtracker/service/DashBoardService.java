package com.springbootproject.wealthtracker.service;

import com.springbootproject.wealthtracker.dto.DashBoardHomeDTO;

public interface DashBoardService {
    DashBoardHomeDTO getDashBoardData(int userId);



}
