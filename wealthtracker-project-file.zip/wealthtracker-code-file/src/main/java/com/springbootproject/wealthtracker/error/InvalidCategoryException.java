package com.springbootproject.wealthtracker.error;

public class InvalidCategoryException extends RuntimeException{

    public InvalidCategoryException(String message){
        super(message);
    }
}
