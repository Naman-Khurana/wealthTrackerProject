package com.springbootproject.wealthtracker.service;

import org.springframework.stereotype.Service;


public interface InsightsService {

    String getExpenseInsights(int expenseId);


}
